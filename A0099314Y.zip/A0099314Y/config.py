# whether to eliminate stop words
ELIMINATE_STOP_WORDS = False
# whether to eliminate numbers
ELIMINATE_NUMBERS = False